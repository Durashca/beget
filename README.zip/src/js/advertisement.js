<!--    зона рекламы-->
// Получаем элемент кнопки
const createPageButton = document.getElementById('advertisement');

addEventListener('DOMContentLoaded', function () {
// Вставляем HTML-разметку после кнопки
    createPageButton.insertAdjacentHTML('afterend', `

`);
})
