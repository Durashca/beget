console.log('tr.js')

addEventListener('DOMContentLoaded', function (){
    let transition_warning = document.getElementById('transition_warning');
    transition_warning.addEventListener('click', function () {

                func_tg_wrong();

    })

})
